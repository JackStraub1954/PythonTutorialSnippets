# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


def funk(**pairs):
    # Use a breakpoint in the code line below to debug your script.
    print(len(pairs))
    for pair in pairs:
        print(pair + ", " + str(pairs[pair]))


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    funk(fname="Charles", lname="Roundhouse", color="BLUE", age=14)

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
